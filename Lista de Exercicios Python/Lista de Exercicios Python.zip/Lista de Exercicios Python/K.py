input()
lista = map(int, raw_input().split())
lista.sort()
print (lista[0])

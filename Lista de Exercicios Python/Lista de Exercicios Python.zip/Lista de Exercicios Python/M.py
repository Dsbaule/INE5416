A, B, C = map(int, raw_input().split())
X, Y, Z = map(int, raw_input().split())
print(int(X/A) * int(Y/B) * int(Z/C))

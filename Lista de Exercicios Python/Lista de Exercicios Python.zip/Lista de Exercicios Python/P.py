L = input()
P = 1

while(L >= 2):
    L /= 2
    P *= 4

print (P)

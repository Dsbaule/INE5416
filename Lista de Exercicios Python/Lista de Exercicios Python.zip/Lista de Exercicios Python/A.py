pressaoDesejada = int(input())
pressaoLida = int(input())

print (pressaoDesejada - pressaoLida)

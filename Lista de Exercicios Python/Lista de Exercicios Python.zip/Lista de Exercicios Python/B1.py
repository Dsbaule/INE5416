numeroDeVisitantes = int(input())
print (numeroDeVisitantes * 2 * 2)

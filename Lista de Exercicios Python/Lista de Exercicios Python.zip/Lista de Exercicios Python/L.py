A, B, C = map(int, raw_input().split())
print(min(A/2, B/3, C/5))

x = bool(input())
y = bool(input())

print (lambda x, y: x != y)(x, y)

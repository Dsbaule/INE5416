N1, N2, N3 = map(float, raw_input().split())

print (lambda n1, n2, n3: (((n1 + n2 + n3)/3)) >= 6)(N1, N2, N3)

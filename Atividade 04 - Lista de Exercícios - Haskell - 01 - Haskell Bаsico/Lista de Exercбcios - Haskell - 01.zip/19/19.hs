conjGold :: Int -> Int


main = do
  print "Numero:"
  nString <- getLine
  let n = (read nString :: Int
  print (conjGold n)
